MXCHIP:
  EMW3165: Footprint not validated with print-copie and part yet
MaLoutre:
  It's me. My avatar converted for boards.
